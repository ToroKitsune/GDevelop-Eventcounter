import json
import tkinter as tk
from tkinter import filedialog, messagebox

# ---------------------------------------------------------
#  EVENT COUNTING LOGIC
# ---------------------------------------------------------
def count_events_in_object(obj):
    count = 0

    if isinstance(obj, dict):
        for key, value in obj.items():
            if key == "events" and isinstance(value, list):
                count += len(value)
            count += count_events_in_object(value)

    elif isinstance(obj, list):
        for item in obj:
            count += count_events_in_object(item)

    return count


# ---------------------------------------------------------
#  GUI LOGIC
# ---------------------------------------------------------
selected_file = None

def select_file():
    global selected_file
    path = filedialog.askopenfilename(
        title="Select GDevelop Project JSON",
        filetypes=[("JSON Files", "*.json")]
    )
    if path:
        selected_file = path
        file_label.config(text=f"Selected: {path}")


def run_count():
    if not selected_file:
        messagebox.showerror("Error", "No file selected")
        return

    try:
        with open(selected_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        scene_total = 0
        behavior_total = 0
        external_total = 0

        if "layouts" in data:
            for scene in data["layouts"]:
                scene_total += count_events_in_object(scene)

        if "eventsFunctionsExtensions" in data:
            for ext in data["eventsFunctionsExtensions"]:
                behavior_total += count_events_in_object(ext)

        if "externalEvents" in data:
            for ext_event in data["externalEvents"]:
                external_total += count_events_in_object(ext_event)

        grand_total = scene_total + behavior_total + external_total

        output_box.delete("1.0", tk.END)
        output_box.insert(tk.END,
            f"Scene Events: {scene_total}\n"
            f"Behavior Events: {behavior_total}\n"
            f"External Events: {external_total}\n"
            f"-----------------------------\n"
            f"TOTAL EVENTS: {grand_total}"
        )
        output_box.tag_add("center", "1.0", "end")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to read file:\n{e}")


# ---------------------------------------------------------
#  GUI SETUP
# ---------------------------------------------------------
root = tk.Tk()
root.title("GDevelop Event Counter")
root.geometry("500x330")

# Window icon (.ico)
try:
    root.iconbitmap("Resources/eventcounter.ico")
except Exception as e:
    print("ICO icon failed:", e)

select_button = tk.Button(root, text="Select JSON File", command=select_file)
select_button.pack(pady=10)

file_label = tk.Label(root, text="No file selected")
file_label.pack()

run_button = tk.Button(root, text="Run Event Count", command=run_count)
run_button.pack(pady=10)

output_box = tk.Text(root, height=12, width=60)
output_box.pack(pady=10)

output_box.tag_configure("center", justify="center")

root.mainloop()
